package com.mycompany.poe_part1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Message {

    Scanner input = new Scanner(System.in);

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    private boolean isSent;

    private static int totalMessageSent = 0;
    public ArrayList<Message> allMessages = new ArrayList<>();

    public Message() {
        this.messageID = generateMessageID();
        this.isSent = false;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;

        // Generate hash AFTER message exists
        this.messageHash = createMessageHash();
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public boolean isSent() {
        return isSent = true;
    }

    private String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long) (rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    public boolean checkMsessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        Login loginChecker = new Login();
        boolean valid = loginChecker.checkCellPhoneNumber(recipient);
        if (valid) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again";
        }

    }

    public String createMessageHash() {
        if (messageText == null || messageText.isEmpty()) {
            return "";
        }

        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord;

        if (words.length > 1) {
            lastWord = words[words.length - 1];
        } else {
            lastWord = firstWord;
        }
        lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");

        String hash = firstTwo + ":" + messageNumber + ":" + firstWord + lastWord;

        return hash.toUpperCase();
    }

    public String sentMessage(Scanner scanner) {
        System.out.println("nWhat would you like to do with this message?");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");
        System.out.println("Enter choice:");

        int choice = scanner.nextInt();
        scanner.nextLine();

        if (choice == 1) {
            isSent = true;
            totalMessageSent++;
            storeMessageToJSON();
            return "Message successfully sent.";
        } else {
            return "Invalid option. Message disregarded.";
        }
    }

    public String printMessages() {
        if (allMessages.isEmpty()) {
            return "No messages have been created yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : allMessages) {
            sb.append("messageID:").append(m.messageID).append("\n");
            sb.append("MessageHash:").append(m.messageHash).append("\n");
            sb.append("Recipient:").append(m.recipient).append("\n");
            sb.append("Message:").append(m.messageText).append("\n");
            sb.append("Status:").append(m.isSent ? "Sent" : "Stored").append("\n");

            sb.append("----------------------------------\n");

        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return totalMessageSent;
    }

    public void storeMessageToJSON() {
        try (FileWriter fw = new FileWriter("messages.json", true)) {
            String json = "{ \"messageID\": \"" + messageID + "\", "
                    + "\"messageNumber\": " + messageNumber + ", "
                    + "\"recipient\": \"" + recipient + "\", "
                    + "\"messageText\": \"" + messageText.replace("\"", "\\\"") + "\", "
                    + "\"messageHash\": \"" + messageHash + "\", "
                    + "\"isSent\": " + isSent + " }\n";
            fw.write(json);
        } catch (IOException e) {
            System.out.println("Error saving message to JSON: " + e.getMessage());
        }
    }

}
