/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe_part1;

import java.util.regex.Pattern;

/**
 *
 * @author Student
 */
public class Login {
    
    private String storedUsername;
    private String storedPassword;
    private String storedCellNumber;
    private String userFirstName;
    private String userLastName;
   
    /**
     * Checks if username contains an underscore (_) and is no more than 5 characters long.
     */
    public boolean checkUserName(String username) {
        if (username == null) {
            return false;
        }
        return username.contains("_") && username.length() <= 5;
    }
   
    /**
     * Checks if password meets complexity requirements:
     * - At least 8 characters long
     * - Contains a capital letter
     * - Contains a number
     * - Contains a special character
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
       
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
       
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
           
            if (c >= 'A' && c <= 'Z') {
                hasCapital = true;
            } else if (c >= '0' && c <= '9') {
                hasNumber = true;
            } else if (!(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') && !(c >= '0' && c <= '9')) {
                hasSpecial = true;
            }
        }
       
        return hasCapital && hasNumber && hasSpecial;
    }
   
    /**
     * Checks if cell phone number contains international country code (+27 for South Africa)
     * and is no more than 10 characters after the country code.
     * Uses regex pattern to validate the format.
     *
     * Reference: Regular expression pattern for international phone numbers
     * Source: https://stackoverflow.com/questions/16779061/regex-for-international-phone-number
     */
    public boolean checkCellPhoneNumber(String cellNumber) {
        if (cellNumber == null) {
            return false;
        }
       
        // Regex pattern for South African cell numbers with international code
        // Format: +27 followed by 9 digits (total 12 characters including +)
        String regex = "^\\+27[0-9]{9}$";
       
        return Pattern.matches(regex, cellNumber);
    }
   
    /**
     * Registers a new user with username, password, and cell phone number.
     */
    public String registerUser(String username, String password, String cellNumber,
                                String firstName, String lastName) {
       
        boolean usernameValid = checkUserName(username);
        boolean passwordValid = checkPasswordComplexity(password);
        boolean cellValid = checkCellPhoneNumber(cellNumber);
       
        if (!usernameValid) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
       
        if (!passwordValid) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
       
        if (!cellValid) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
       
        storedUsername = username;
        storedPassword = password;
        storedCellNumber = cellNumber;
        userFirstName = firstName;
        userLastName = lastName;
       
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }
   
    /**
     * Verifies if the entered login details match the stored user credentials.
     */
    public boolean loginUser(String username, String password) {
        if (storedUsername == null || storedPassword == null) {
            return false;
        }
        return storedUsername.equals(username) && storedPassword.equals(password);
    }
   
    /**
     * Returns the login status message based on authentication result.
     */
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + userFirstName + " " + userLastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
   
    public String getStoredUsername() {
        return storedUsername;
    }
}
    


    

