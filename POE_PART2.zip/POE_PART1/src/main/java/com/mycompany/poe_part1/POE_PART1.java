/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.poe_part1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class POE_PART1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();
        //Message msg = new Message();
        int choice;
        int totalMessages = 0;

        System.out.println("==================================================");
        System.out.println("    WELCOME TO THE REGISTRATION & LOGIN SYSTEM");
        System.out.println("==================================================");

        do {
            System.out.println("Enter your choice (1-3): \n1. Register "
                    + "\n2. Login "
                    + "\n3.Exit");
            choice = input.nextInt();
            input.nextLine();

            if (choice == 1) {
                System.out.println("\n--- REGISTRATION ---");
                System.out.println("Username must contain an underscore (_) and be no more than 5 characters");
                System.out.println("Password must be at least 8 characters, contain a capital letter, a number, and a special character");
                System.out.println("Cell phone must start with +27 and have 9 digits");
                System.out.println("----------------------------------------");

                System.out.print("Enter your first name: ");
                String firstName = input.nextLine();

                System.out.print("Enter your last name: ");
                String lastName = input.nextLine();

                System.out.print("Enter username: ");
                String username = input.nextLine();

                System.out.print("Enter password: ");
                String password = input.nextLine();

                System.out.print("Enter cell phone number: ");
                String cellNumber = input.nextLine();

                // Check each validation separately
                boolean usernameValid = login.checkUserName(username);
                boolean passwordValid = login.checkPasswordComplexity(password);
                boolean cellValid = login.checkCellPhoneNumber(cellNumber);

                System.out.println("\n--- VALIDATION RESULTS ---");

                if (!usernameValid) {
                    System.out.println("✗ Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
                } else {
                    System.out.println("✓ Username is correct");
                }

                if (!passwordValid) {
                    System.out.println("✗ Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
                } else {
                    System.out.println("✓ Password is correct");
                }

                if (!cellValid) {
                    System.out.println("✗ Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
                } else {
                    System.out.println("✓ Cell number is correct");
                }

                // Only register if ALL are valid
                if (usernameValid && passwordValid && cellValid) {
                    String result = login.registerUser(username, password, cellNumber, firstName, lastName);
                    System.out.println("\n" + result);
                } else {
                    System.out.println("\nRegistration failed. Please correct the errors above.");
                }

            } else if (choice == 2) {
                if (login.getStoredUsername() == null) {
                    System.out.println("\nNo user registered yet. Please register first.");
                } else {
                    System.out.println("\n--- LOGIN ---");
                    System.out.print("Enter username: ");
                    String username = input.nextLine();

                    System.out.print("Enter password: ");
                    String password = input.nextLine();

                    String status = login.returnLoginStatus(username, password);
                    System.out.println("\n" + status);

                    //Part 2 code
                    System.out.println("Welcome to QuickChat");

                    int menuOption = 0;

                    do {
                        System.out.println("Enter your option:\n1. Send Message "
                                + "\n2. Show recently sent messages "
                                + "\n3. Quit");

                        menuOption = input.nextInt();
                        switch (menuOption) {
                            case 1:
                                System.out.println("How many messages do you want to send??");
                                int numOfMessage = input.nextInt();

                                for (int i = 0; i < numOfMessage; i++) {

                                    Message msg = new Message();

                                    // MESSAGE ID
                                    String messageID = msg.getMessageID();

                                    System.out.println("Please enter recipient number");
                                    String recipientNum = input.nextLine();
                                    msg.checkRecipientCell();

                                    input.nextLine();

                                    System.out.println("Please enter message");
                                    String sendMsg = input.nextLine();
                                    if (sendMsg.length() > 250) {
                                        System.out.println("Please enter a message of less than 250 characters");
                                    }
                                    msg.setMessageText(sendMsg);
                                    msg.createMessageHash();

                                    // SEND OPTIONS
                                    System.out.println("Choose: \n1. Send Message "
                                            + "\n2. Disregard Message "
                                            + "\n3. Store Message");

                                    int sendOption = input.nextInt();
                                    input.nextLine();

                                    switch (sendOption) {
                                        case 1:
                                            msg.isSent();

                                            totalMessages++;

                                            msg.allMessages.add(msg);

                                            msg.storeMessageToJSON();

                                            // DISPLAY MESSAGE DETAILS
                                            System.out.println("\n----- MESSAGE DETAILS -----");

                                            System.out.println("Message ID: " + messageID);

                                            System.out.println("Message Hash: " + msg.getMessageHash());

                                            System.out.println("Recipient: " + recipientNum);

                                            System.out.println("Message: " + sendMsg);

                                            System.out.println("---------------------------");
                                            System.out.println("Message successfully sent");

                                            break;
                                        case 2:
                                            System.out.println("Press 0 to delete message");

                                            break;
                                        case 3:
                                            System.out.println("Message successfully stored");
                                            break;
                                        default:
                                            System.out.println("Invalid input. Enter a number between 1 and 3");
                                            break;
                                    }
                                }
                                System.out.println("\nTOTAL MESSAGES SENT: " + Message.returnTotalMessages());
                                break;
                            case 2:
                                System.out.println("Coming Soon");
                                break;
                            case 3:
                                System.out.println("GoodBye........................");
                                break;
                            default:
                                System.out.println("Invalid input. Enter a number between 1 and 3");
                                break;

                        }
                    } while (menuOption != 3);//end of do while loop

                }//end of if Statement

            } else if (choice == 3) {
                System.out.println("\nThank you for using the system!");
            } else {
                System.out.println("\nInvalid choice!");
            }

        } while (choice != 3);

        input.close();
    }
}
