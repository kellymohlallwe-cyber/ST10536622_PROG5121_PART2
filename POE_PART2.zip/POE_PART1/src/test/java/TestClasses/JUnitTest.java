/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package TestClasses;

import com.mycompany.poe_part1.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;

/**
 *
 * @author Student
 */
public class JUnitTest {
    
    private Login login;

    // Initialize Login object before each test
    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    // Test for Username Validation
    @Test
    public void testCheckUserName() {
        // Valid username
        assertTrue(login.checkUserName("user_1"));
        // Invalid username: no underscore
        assertFalse(login.checkUserName("user1"));
        // Invalid username: too long
        assertFalse(login.checkUserName("user_long"));
        // Invalid username: underscore in wrong position
        assertFalse(login.checkUserName("us_er"));
        // Invalid username: null
        assertFalse(login.checkUserName(null));
    }

    // Test for Password Complexity Validation
    @Test
    public void testCheckPasswordComplexity() {
        // Valid password
        assertTrue(login.checkPasswordComplexity("Password1@"));
        // Invalid password: no capital letter
        assertFalse(login.checkPasswordComplexity("password1@"));
        // Invalid password: no number
        assertFalse(login.checkPasswordComplexity("Password@"));
        // Invalid password: no special character
        assertFalse(login.checkPasswordComplexity("Password123"));
        // Invalid password: too short
        assertFalse(login.checkPasswordComplexity("Pass1@"));
        // Invalid password: null
        assertFalse(login.checkPasswordComplexity(null));
    }

    // Test for Cell Phone Number Validation
    @Test
    public void testCheckCellPhoneNumber() {
        // Valid phone number
        assertTrue(login.checkCellPhoneNumber("+27123456789"));
        // Invalid phone number: missing international code
        assertFalse(login.checkCellPhoneNumber("123456789"));
        // Invalid phone number: wrong international code
        assertFalse(login.checkCellPhoneNumber("+28123456789"));
        // Invalid phone number: incorrect length
        assertFalse(login.checkCellPhoneNumber("+27123"));
        // Invalid phone number: null
        assertFalse(login.checkCellPhoneNumber(null));
    }

    // Test for User Registration
    @Test
    public void testRegisterUser() {
        // Valid registration
        String result = login.registerUser("user_1", "Password1@", "+27123456789", "John", "Doe");
        assertEquals("Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.", result);

        // Invalid username (too long)
        result = login.registerUser("userlong", "Password1@", "+27123456789", "John", "Doe");
        assertEquals("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.", result);

        // Invalid password (too short)
        result = login.registerUser("user_1", "pass", "+27123456789", "John", "Doe");
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", result);

        // Invalid phone number (incorrect format)
        result = login.registerUser("user_1", "Password1@", "123", "John", "Doe");
        assertEquals("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.", result);
    }

    // Test Login Status
    @Test
    public void testReturnLoginStatus() {
        login.registerUser("user_1", "Password1@", "+27123456789", "John", "Doe");

        // Valid login
        String status = login.returnLoginStatus("user_1", "Password1@");
        assertEquals("Welcome John Doe, it is great to see you again.", status);

        // Invalid login - wrong username
        status = login.returnLoginStatus("wrong_user", "Password1@");
        assertEquals("Username or password incorrect, please try again.", status);

        // Invalid login - wrong password
        status = login.returnLoginStatus("user_1", "WrongPassword@");
        assertEquals("Username or password incorrect, please try again.", status);
    }

    // Test Login Status with Null Values
    @Test
    public void testReturnLoginStatusWithNullValues() {
        String status = login.returnLoginStatus(null, null);
        assertEquals("Username or password incorrect, please try again.", status);
    }
    
}
